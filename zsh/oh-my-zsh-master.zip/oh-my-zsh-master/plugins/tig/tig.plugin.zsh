alias tis='tig status'
alias til='tig log'
alias tib='tig blame -C'
