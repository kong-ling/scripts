# Bwana

This plugin provides a function to open `man` pages directly with [Bwana](https://www.bruji.com/bwana/).

To use it add bwana to the plugins array in your zshrc file.

```bash
plugins=(... bwana)
```
